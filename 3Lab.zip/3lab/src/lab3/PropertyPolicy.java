package lab3;

abstract class PropertyPolicy extends Policy {
	
	protected float liability;
	
	protected void setLCoverage(float lCoverage){
		liability = lCoverage;
	}
	
	protected float getLCoverage(){
		return liability;
	}

}
