package lab1;

public class lab1test {

}
