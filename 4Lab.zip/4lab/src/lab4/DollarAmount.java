package lab4;

public class DollarAmount {
	
	private double dollars;
	
	DollarAmount(double total){
		dollars =  total;
	}

	
	public void fewestBills(){
		
		if((dollars / 10) > 1){
			System.out.println((int) ((dollars / 10)) + " Ten dollar bills");
			dollars =  (dollars % 10);
		}
			
		if((dollars / 5) > 1){
			System.out.println((int) ((dollars / 5)) + " Five dollar bills");
			dollars =  (dollars % 5);
		}
		
		if((dollars / 1) > 1){
			System.out.println((int) ((dollars / 1)) + " One dollar bills");
			dollars =   (dollars % 1);
		}
		
		if((dollars / 0.25) > 1){
			System.out.println((int) ((dollars / 0.25)) + " Quarters");
			dollars =  (dollars % 0.25);
		}
		
		if((dollars / 0.10) > 1){
			System.out.println((int) ((dollars / 0.10)) + " Dimes");
			dollars =  (dollars % 0.10);
		}
		if((dollars / 0.05) > 1){
			System.out.println((int) ((dollars / 0.05)) + " Nickles");
			dollars =  (dollars % 0.05);
		}
		
		if((dollars / 0.01) > 1){
			System.out.println((int) (Math.round(dollars / 0.01)) + " Pennies");
		}
	}
}
