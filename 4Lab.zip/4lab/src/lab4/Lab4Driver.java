package lab4;

import java.util.Scanner;

public class Lab4Driver {


	public static void main(String[] args) {
		
		
		double currentAmount = 0;
		String userChoice = "";
		Scanner userOption = new Scanner(System.in);
		
		System.out.println("Enter your Dollar amount; Type \"quit\" to exit: ");
		
		userChoice = userOption.next();
		
		while (!userChoice.equals ("quit")){
			
			try{
				currentAmount = Double.parseDouble(userChoice);
				DollarAmount tempAmount = new DollarAmount(currentAmount);
				tempAmount.fewestBills();
			}
			catch(NumberFormatException exception){
				System.out.println("EXCEPTION: Invalid input");
			}
			finally{
				System.out.println("Processing completed");
			}
				
			System.out.println("Enter your Dollar amount; Type \"quit\" to exit: ");
			userChoice = userOption.next();

		}
			
	}
}
