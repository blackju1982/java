package lab3;

public class CarPolicy extends PropertyPolicy {
	
	private String make, model;
	private float collision;
	
	public CarPolicy(String fName, String lName, String carMake, String carModel, float lCoverage, float cCoverage){
		holderName = new PolicyHolder(fName, lName, 0);
		make = carMake;
		model = carModel;
		liability = lCoverage;
		collision = cCoverage;
		
	}
	
	public void setMake(String carMake){
		make = carMake;
	}
	
	public void setModel(String carModel){
		model = carModel;
	}
	
	public void setCCoverage(float cCoverage){
		collision = cCoverage;
	}
	
	public String getMake(){
		return make;
	}
	
	public String getModel(){
		return model;
	}
	
	public float getCCoverage(){
		return collision;
	}
	
	public float salesCommission(){
		commission = (float) ((liability + collision) * 0.3);
		
		return commission;
	}
	
	public String toString(){
		return "Policy Holder: " + holderName + "\n" +
				"Vehicle Make and Model: " + make + ", " + model + "\n" +
				"Liability Coverage: " + liability + "\n" +
				"Collision Coverage " + collision + "\n" +
				"Sales Commision Earned: "+ salesCommission();
	}
}
