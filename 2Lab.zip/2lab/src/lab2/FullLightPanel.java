package lab2;

import java.awt.*;
import javax.swing.*;

public class FullLightPanel extends JPanel {
	
	private DrawLightPanel draw;
	private EventLightPanel control;
	
	//add button and light to a "control" panel
	public FullLightPanel(){
		
		setBackground(Color.white);
		
		draw = new DrawLightPanel();
		control = new EventLightPanel();
		
		control.setDraw(draw);
		
		add(draw);
		add(control);
		
		
	}

}
