package lab5;

import java.awt.*;
import javax.swing.*;

public class FullTrianglePanel extends JPanel {
	
	private DrawTrianglePanel draw;
	private MoreLessButtonPanel control;
	
	public FullTrianglePanel(){
		
		setLayout(new BorderLayout());
	
		setBackground(Color.white);
		
		draw = new DrawTrianglePanel();
		control = new MoreLessButtonPanel();
		
		control.setDraw(draw);
		
		add(draw, BorderLayout.CENTER);
		add(control, BorderLayout.NORTH);
	}

}
