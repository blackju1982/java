package lab2;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;



public class EventLightPanel extends JPanel {
	
	private DrawLightPanel draw;
	
	private JButton press;
	
	public EventLightPanel (){
	
		//button to change light
		press = new JButton("Press to Change");
		press.addActionListener (new ButtonListener());
		
		//add button
		add(press);
	
		//default button frame size and color
		setPreferredSize (new Dimension(200,400));
		setBackground (Color.white);
	}

	//class for button actions
	private class ButtonListener implements ActionListener{
		
		public int state = 1;
		public int direction = 1;
		
		//cycles through 1-3 and back down 3-1
		public void actionPerformed (ActionEvent event){
			
			//temporary state variable
			int newState = state + direction;
			
			//change direction from ++ to -- once the floor or ceiling is
			if(newState == 1 || newState == 3){
				direction *= -1;
			}
			
			//causes ++ or -- based on direction to be stored
			state = newState;
			
			//for testing purposes
			//System.out.println(state);
			
			//input "state" to dictate colors displayed
			draw.changeColors(state);
			
			//make changes take affect
			draw.repaint();
		}

	}
	
	public DrawLightPanel getDraw() {
		return draw;
	}
	
	public void setDraw(DrawLightPanel draw) {
		this.draw = draw;
	}

}