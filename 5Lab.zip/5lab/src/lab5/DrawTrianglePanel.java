package lab5;

import java.awt.*;
import javax.swing.JPanel;

public class DrawTrianglePanel extends JPanel {
	
	int MAXWIDTH = 500, MAXHEIGHT = 500;

	//first triangle variables
	int x1 = 0, x2 = MAXHEIGHT/2, x3 = MAXHEIGHT;
	int y1 = MAXWIDTH, y2 = 0, y3 = MAXWIDTH;
	private int numOfTriangles = 1;
	
	public DrawTrianglePanel (){
		
		//default light frame size and color
		setPreferredSize (new Dimension(MAXHEIGHT, MAXWIDTH + 1));
		setBackground (Color.white);
	}
	
	protected void paintComponent(Graphics g) {
		
		// Draw parent class
		super.paintComponent(g);
		
		//Initial triangle
		subTriangle(g, x1, y1, x2, y2, x3, y3, numOfTriangles);
	}
	
	public void subTriangle (Graphics window, int x1, int y1, int x2, int y2, int x3, int y3, int n){

		        if(Math.sqrt((double)(Math.pow(x2-x1, 2)) + (double)(Math.pow(y2-y1, 2))) > 2){
		        	
		        	int xPoints[] = {x1, x2, x3};
		        	int yPoints[] = {y1, y2, y3};
		        	
		        	window.drawPolygon(xPoints, yPoints, 3);
		        }
		        
		        if(n > 0){
			        for(int i = 0; i < n; i++){
			        	
			        	// make 3 new triangles by connecting the midpoints of the previous triangle
				        int xa, ya, xb, yb, xc, yc;   
				        xa = (x1 + x2) / 2;
				        ya = (y1 + y2) / 2;
				        xb = (x1 + x3) / 2;
				        yb = (y1 + y3) / 2;
				        xc = (x2 + x3) / 2;
				        yc = (y2 + y3) / 2;
		
				        // recursively call the function using the 3 triangles
				        subTriangle(window, x1, y1, xa, ya, xb, yb, n-1);   
				        subTriangle(window, xa, ya, x2, y2, xc, yc, n-1);
				        subTriangle(window, xb, yb, xc, yc, x3, y3, n-1);
			        }
		        }
	}
	
	public int layerUp(){
		//more than 6 locked up my machine
		if(numOfTriangles < 6){
			numOfTriangles += 1;
			System.out.println(numOfTriangles);
		}
		else{
				System.out.println("The triangles are too small to view!");
			}
		return numOfTriangles;
	}
	
	public int layerDown(){
		if(numOfTriangles > 0){
			numOfTriangles -= 1;
			System.out.println(numOfTriangles);
		}
		else{
			System.out.println("Already at 0!");
		}
		return numOfTriangles;
	}
	
	public int getNumOfTriangles(){
		return numOfTriangles;
	}

}

