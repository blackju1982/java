package lab2;

import javax.swing.*;

public class lab2 {


	public static void main(String[] args) {
		
		//bring in FullLightPanel
		JFrame frame = new JFrame ("StopLightPanel");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.getContentPane().add(new FullLightPanel());
		
		frame.pack();
		frame.setVisible(true);
		
		

	}

}
