package lab3;

public class HomePolicy extends PropertyPolicy {
	
	private int sqFt;
	private float dwelling, contents;

	public HomePolicy(String fName, String lName, int sqFootage, float dCoverage, float cCoverage, float lCoverage){
		holderName = new PolicyHolder(fName, lName, 0);
		sqFt = sqFootage;
		dwelling = dCoverage;
		contents = cCoverage;
		liability = lCoverage;
		
	}
	
	public void setSqFootage(int sqFootage){
		sqFt = sqFootage;
	}
	
	public void setDCoverage(float dCoverage){
		contents = dwelling;
	}
	
	public void setCCoverage(float cCoverage){
		contents = cCoverage;
	}
	
	public int getSqFootage(){
		return sqFt;
	}
	
	public float getDCoverage(){
		return dwelling;
	}
	
	public float getCCoverage(){
		return contents;
	}
	
	public float salesCommission(){
		commission = (float) ((liability * 0.3) + ((dwelling + contents) * 0.2));
		
		return commission;
	}
	
	public String toString(){
		return "Policy Holder: " + holderName + "\n" +
				"Dwelling Square Footage: " + sqFt + "\n" +
				"Dwelling Coverage: " + dwelling + "\n" +
				"Collision Coverage " + contents + "\n" +
				"Liability Coverage: " + liability + "\n" +
				"Sales Commision Earned: "+ salesCommission();
	}
}
