package lab5;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class MoreLessButtonPanel extends JPanel {
	
	private DrawTrianglePanel draw;
	private JButton pressMore, pressLess;
	private JLabel output;
	private int outputCount;
	
	public MoreLessButtonPanel(){
		
		//buttons to add/remove triangles
		pressMore = new JButton("Press for more Triangles");
		pressMore.addActionListener(new outputListener());
		pressMore.addActionListener(new MoreButtonListener());
		add(pressMore);
		
		pressLess = new JButton("Press for less Triangles");
		pressLess.addActionListener(new outputListener());
		pressLess.addActionListener(new LessButtonListener());
		add(pressLess);
		
		//counter label
		output = new JLabel("Number of iterations: 1");
		add(output);
		
		//default button frame size and color
		setPreferredSize (new Dimension(500,50));
		setBackground(Color.white);
	}
	
	private class MoreButtonListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent event) {
			draw.layerUp();
			draw.repaint();
		}
		
	}
	
	private class LessButtonListener implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent event) {
			draw.layerDown();
			draw.repaint();
		}
		
	}
	
	private class outputListener implements ActionListener{
		
		@Override
		public void actionPerformed(ActionEvent event) {
			outputCount = draw.getNumOfTriangles();
			output.setText("Number of iterations: " + outputCount);
		}
	}
	
	public DrawTrianglePanel getDraw() {
		return draw;
	}
	
	public void setDraw(DrawTrianglePanel draw) {
		this.draw = draw;
	}
	
}
