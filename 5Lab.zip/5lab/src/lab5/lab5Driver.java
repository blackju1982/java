package lab5;

import javax.swing.*;

public class lab5Driver {


	public static void main(String[] args) {
		
		JFrame frame = new JFrame ("Triangle");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		frame.getContentPane().add(new FullTrianglePanel());
		
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}

}
