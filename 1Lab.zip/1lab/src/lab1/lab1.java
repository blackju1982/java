package lab1;


import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JApplet;
import java.util.Random;

public class lab1 extends JApplet {


	public void paint(Graphics page) {
		
		Random r = new Random();
		
		setBackground(Color.white);
		
		setSize(400,400);
		
		//variable number of pieces can be done
		int pieces = 8;
		float angleDegrees = (float) (360.0/pieces);
		
		//variable diameter can be changed, must be less than setSize bounds
		int diameter = 200;
		int radius = diameter / 2;
		page.setColor(Color.black);
		page.drawOval(0, 0, diameter, diameter);
		
		for(float i = 0; i <= 360.0; i += angleDegrees){
			
			//find sin and cos then draw lines at appropriate angles
			//lengthOfLine and origin are equal to radius due to plotting system
			//x = originx + lengthOfLine * sin(angle)
			//y = originy + lengthOfLine * cos(angle)
			double plotx = radius + radius * Math.sin(Math.toRadians(i));
			double ploty = radius + radius * Math.cos(Math.toRadians(i));
			
			page.setColor(Color.black);
			page.drawLine(radius, radius, (int) plotx, (int) ploty);
			
			//create colored pieces
			page.setColor(new Color(r.nextInt(256), r.nextInt(256), r.nextInt(256)));
			page.fillArc(0, 0, diameter, diameter, (int) i, (int) angleDegrees);
		}
	}
	
}
