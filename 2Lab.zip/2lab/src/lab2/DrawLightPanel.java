package lab2;

import java.awt.*;
import javax.swing.*;


public class DrawLightPanel extends JPanel {
	
	private Color redLight = Color.RED;
	private Color yellowLight = Color.YELLOW;
	private Color greenLight = Color.GREEN;

	
	public DrawLightPanel (){
	
		//default light frame size and color
		setPreferredSize (new Dimension(200,400));
		setBackground (Color.black);
	}

	
	protected void paintComponent(Graphics g) {
		
		// Draw parent class
		super.paintComponent(g);
		
		//Initial colors all show
		g.setColor(redLight);
		g.fillOval(50, 50, 100, 100);
		
		g.setColor(yellowLight);
		g.fillOval(50, 150, 100, 100);
		
		g.setColor(greenLight);
		g.fillOval(50, 250, 100, 100);
	}
	
	//turns all but one light "off" based on a "state"
	public void changeColors(int position){
		if (position == 1){
			redLight = Color.BLACK;
			yellowLight = Color.BLACK;
			greenLight = Color.GREEN;
		}
		if (position == 2){
			redLight = Color.BLACK;
			yellowLight = Color.YELLOW;
			greenLight = Color.BLACK;
		}
		if (position == 3){
			redLight = Color.RED;
			yellowLight = Color.BLACK;
			greenLight = Color.BLACK;
		}
		
	}
	
}
