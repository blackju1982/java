package lab3;

public class PolicyHolder {

	protected String firstName, lastName;
	protected int age;
	
	public PolicyHolder(String fName, String lName, int yearsOld){
		firstName = fName;
		lastName = lName;
		age = yearsOld;
	}
	
	public void setFirstName(String fName){
		firstName = fName;
	}
	
	public void setLastName(String lName){
		lastName = lName;
	}
	
	public void setAge(int yearsOld){
		age = yearsOld;
	}
	
	public String getFirstName(){
		return firstName;
	}
	
	public String getLastName(){
		return lastName;
	}
	
	public int getAge(){
		return age;
	}
	
	public String toString(){
		if(age == 0){
			return lastName + ", " + firstName;
		}
		else return lastName + ", " + firstName + "\n" +
		"Age: " + age;
	}
}
