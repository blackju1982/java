package lab3;

public class LifePolicy extends Policy {
	
	private float termLife;
	
	public LifePolicy(String fName, String lName, int yearsOld, float termCoverage){
		holderName = new PolicyHolder(fName, lName, yearsOld);
		
		termLife = termCoverage;
	}
	
	public void setTermCoverage(float termCoverage){
		termLife = termCoverage;
	}

	public float getTermCoverage(){
		return termLife;
	}
	
	public float salesCommission(){
		commission = (float) (termLife * 0.2);
		
		return commission;
	}
	
	public String toString(){
		return "Policy Holder: " + holderName + "\n" +
				"Term Life Coverage: " + termLife + "\n" +
				"Sales Commision Earned: "+ salesCommission();
	}
	
	
}
