package lab3;


public abstract class Policy {
	
	
	protected PolicyHolder holderName;
	protected float commission = 0;
	
	protected void setName(String fName, String lName, int yearsOld){
		holderName = new PolicyHolder(fName, lName, yearsOld);
	}
	
	protected void setName(String fName, String lName){
		holderName.firstName = fName;
		holderName.lastName = lName;
	}
	
	protected void setAge(int yearsOld){
		holderName.age = yearsOld;
	}
	
	protected String getName(){
		return holderName.toString();
	}
	
	protected float salesCommission(){
		return commission;
	}

}
