package lab3;

import java.util.Scanner;
import java.util.ArrayList;

public class Lab3Driver {


	public static void main(String[] args) {
		
		Scanner userInput = new Scanner(System.in);
		ArrayList<Policy> tempArray = new ArrayList<Policy>();
		//menu place holder
		int currentStage = 0;
		
		
		System.out.println(
		"---------------------------------------\n" +
		"Welsome to the Parkland Insurance Sales\n" +
		"---------------------------------------");
		

		
		while (currentStage != 5){
		
			System.out.println(
			"Enter one of the following commands: \n" +
			"	1) Enter auto insurance sale \n" +
			"	2) Enter home insurance sale \n" +
			"	3) Enter life insurance sale  \n" +
			"	4) Print all sales entered \n" +
			"	5) Exit");
			
			
			currentStage = userInput.nextInt();
		
			//auto
			if (currentStage == 1){
				
				//creates a new CarPolicy object and places it into the tempArray
				System.out.println("To enter a new auto policy we will need you to fill out the following information: ");
				
				System.out.println("Policy Holders first name: ");
				String a = userInput.next();
				
				System.out.println("Policy Holders last name: ");
				String b = userInput.next();
				
				System.out.println("Make of the car: ");
				String c = userInput.next();
				
				System.out.println("The cars' model: ");
				String d = userInput.next();
				
				System.out.println("Liability coverage: ");
				float x = userInput.nextFloat();
				
				System.out.println("and lastly, collision coverage: ");
				float y = userInput.nextFloat();
				
				tempArray.add(new CarPolicy(a, b, c, d, x, y));
				
			}
			
			//home
			else if (currentStage == 2){
				
				//creates a new HomePolicy object and places it into the tempArray
				System.out.println("To enter a new home policy we will need you to fill out the following information: ");
				
				System.out.println("Policy Holders first name: ");
				String a = userInput.next();
				
				System.out.println("Policy Holders last name: ");
				String b = userInput.next();
				
				System.out.println("Square feet of the house: ");
				int q = userInput.nextInt();
				
				System.out.println("Dwelling coverage: ");
				float x = userInput.nextFloat();
				
				System.out.println("Contents coverage: ");
				float y = userInput.nextFloat();
				
				System.out.println("and lastly, liability coverage: ");
				float z = userInput.nextFloat();
				
				tempArray.add(new HomePolicy(a, b, q, x, y, z));
			}
			
			//life
			else if (currentStage == 3){
				
				//creates a new LifePolicy object and places it into the tempArray
				System.out.println("To enter a new life policy we will need you to fill out the following information: ");
				
				System.out.println("Policy Holders first name: ");
				String a = userInput.next();
				
				System.out.println("Policy Holders last name: ");
				String b = userInput.next();
				
				
				System.out.println("Contents coverage: ");
				int q = userInput.nextInt();
				
				System.out.println("and lastly, liability coverage: ");
				float x = userInput.nextFloat();
				
				tempArray.add(new LifePolicy(a, b, q, x));	
			}
			
			//total commissions
			else if (currentStage == 4){
				
				float salesCommissionTotal = 0;
				
				//loop through each element and get commission earned based on class function
				for(int i = 0; i < tempArray.size(); i++){
					salesCommissionTotal += tempArray.get(i).salesCommission();
				}
				
				System.out.println("Total commission earned: " + salesCommissionTotal);
				
			}
			
			//"clean" exit when selected
			else if (currentStage == 5){
				System.out.println("Thank you!");
				System.exit(0);
			}
			
			//error message for invalid options
			else {
				System.out.println("That was not a valid option");
			}
			
		}
		
	}

}
